﻿# MIT License (MITライセンス)

Copyright (c) 2025 SOVOS Project Team (Hanamaruki-ai)
著作権 (c) 2025 SOVOSプロジェクトチーム Hanamaruki-ai)

---

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

本ソフトウェアおよび関連文書ファイル（以下「ソフトウェア」）の複製を入手したすべての人に対し、
無制限に本ソフトウェアを取り扱うことをここに許可します。これには、利用、複製、改変、統合、公開、配布、
サブライセンスの付与、および/または販売の権利、ならびに本ソフトウェアを提供する相手にも同様の行為を許可する権利が含まれますが、
これらに限定されるものではありません。ただし、以下の条件に従うものとします。

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

上記の著作権表示および本許可表示は、本ソフトウェアのすべての複製または重要な部分に含めるものとします。

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

本ソフトウェアは「現状のまま」で提供され、明示的か暗黙的かを問わず、商品性、特定の目的への適合性、および非侵害性に関する保証を含め、いかなる種類の保証もありません。
いかなる場合も、著作者または著作権者は、本ソフトウェアの使用またはその他の本ソフトウェアとの取引から生じる、契約、不法行為、その他の行為にかかわらず、請求、損害、その他の責任について一切責任を負いません。